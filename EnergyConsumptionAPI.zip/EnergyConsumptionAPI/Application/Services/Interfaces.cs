﻿namespace EnergyConsumptionAPI.Services;

public class Interfaces
{
    
}