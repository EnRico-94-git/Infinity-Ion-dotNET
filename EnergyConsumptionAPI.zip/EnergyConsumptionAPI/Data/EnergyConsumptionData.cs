﻿namespace EnergyConsumptionAPI.Data;

public class EnergyConsumptionData
{
    
}